<?php
class Complex {
  public $real;
  public $imaginary;
  
  public function __construct($real = 0, $imaginary = 0) {
    $this->real = $real;
    $this->imaginary = $imaginary;
  }
  
  public function __add($rhs) {
    $ret = clone $this;
    if ($rhs instanceof Complex) {
      $ret->real += $rhs->real;
      $ret->imaginary += $rhs->imaginary;
    } else {
      $ret->real += (int)$rhs;
    }
    return $ret;
  }
  
  public function __mul($rhs) {
    if ($rhs instanceof Complex) {
      return new Complex(($this->real * $rhs->real) - ($this->imaginary * $rhs->imaginary),
                         ($this->real * $rhs->imaginary) + ($this->imaginary * $rhs->real));
    } else {
      $ret = clone $this;
      $ret->real *= (int)$rhs;
      $ret->imaginary *= (int)$rhs;
      return $ret;
    }
  }
}
?>