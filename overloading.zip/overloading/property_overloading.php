<?php 

class Dynamic_properties { 
	
	// storing the variables in the array
	private $data = array();  
	public $declared=10;
	
	// Function definition 
	public function __set($name, $value) { 
		echo "Setting '$name' = '$value'\n"; 
		$this->data[$name] = $value; 
	} 
	
	// Function definition 
	public function __get($name) { 
		echo "Getting '$name' = "; 
		if (array_key_exists($name, $this->data)) { 
			return $this->data[$name]; 
		} 
		return null; 
	} 
	 
} 

// Create an object 
$obj = new Dynamic_properties(); 
// $obj2 = new Dynamic_properties(); 

// creating a dynamic property 'a' to the class Dynamic_properties
$obj->a = 1; 
echo $obj->a . "\n"; 
// creating a dynamic property 'b' to the class Dynamic_properties
$obj->b=3;
echo $obj->b . "\n";

 
 ?> 
